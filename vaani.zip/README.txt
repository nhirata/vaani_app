HASH: 
https://github.com/mozilla/vaani/commit/8c54d69ce03c789221f7c8b007e500d9c2e6f48e
